select count(champion_name) cnt
from champ;